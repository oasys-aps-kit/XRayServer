
This is the WORKING project for XRayServer (Sergey Stepanov's X-Ray Server under OASYS)

THIS VERSION IS UNDER DEVELOPMENT AND IS HIGLY INSTABLE:

             INSTALLATION IS NOT RECOMENDED!!!!

